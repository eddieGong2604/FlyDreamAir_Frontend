//
// Created by tienl on 23/10/2020.
//

#ifndef ASSIGNMENT2CSCI251_EVENTTYPE_H
#define ASSIGNMENT2CSCI251_EVENTTYPE_H


enum EventType {
    TRACK, FIELD
};


#endif //ASSIGNMENT2CSCI251_EVENTTYPE_H
