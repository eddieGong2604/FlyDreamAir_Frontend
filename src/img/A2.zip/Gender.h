//
// Created by tienl on 24/10/2020.
//

#ifndef ASSIGNMENT2CSCI251_GENDER_H
#define ASSIGNMENT2CSCI251_GENDER_H

enum Gender{
    M = 0, F = 1
};
#endif //ASSIGNMENT2CSCI251_GENDER_H
